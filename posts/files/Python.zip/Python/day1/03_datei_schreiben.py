
mannschaft = ['Schmelzer', 'Klose', 'Podolski', 'Sam', \
           'Neuer', 'Loew', 'Schweinsteiger', 'Paule']

out = open('mannschaft.txt', 'w')

nr = 1

for spieler in mannschaft:
    zeile = str(nr) + spieler + '\n'
    out.write(zeile)
    nr = nr + 1

out.close()



