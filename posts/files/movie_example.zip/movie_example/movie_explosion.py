
from PIL import Image, ImageDraw, ImageFont, ImageFilter 
import random

PIECES = 25 # 16
EDGE = 16 # 25
VEC_GROWTH = 1.020 # 1.03
PHASE1_FRAMES = 250
PHASE2_FRAMES = 100

def create_pieces(filename):
    flower = Image.open(filename, 'r')
    flower = flower.resize((PIECES*EDGE, PIECES*EDGE))

    pieces = []
    positions = []
    for x in range(PIECES):
        for y in range(PIECES):
            copy = flower.copy()
            piece = copy.crop((x*EDGE,y*EDGE,(x+1)*EDGE,(y+1)*EDGE))
            pieces.append(piece)
            positions.append((x*EDGE,y*EDGE))
    return pieces, positions

def increment():
    inc = random.random() + 0.1
    if random.random() > 0.5:
        return -inc
    return inc

def randvec():
    return increment(),increment()

def create_image(pieces, positions):
    img = Image.new("RGB",(PIECES*EDGE, PIECES*EDGE))
    for pc, pos in zip(pieces, positions):
        img.paste(pc, pos)
    return img

def move_pieces(positions, vectors):
    new_pos = []
    for pos, vec in zip(positions, vectors):
        new_pos.append((pos[0]+int(vec[0]), pos[1]+int(vec[1])))
    return new_pos

def increase_vectors(vectors):
    new_vecs = []
    for vec in vectors:
        new_vecs.append((vec[0]*VEC_GROWTH, vec[1]*VEC_GROWTH))
    return new_vecs

def write_frame(number, image):
    fno = '000%i'%(number)
    fno = fno[-4:]
    print fno
    img.save('out/frame_%s.png'%(fno))


if __name__ == '__main__':
    pcs, pos = create_pieces('flower.jpg')
    vecs = [randvec() for i in pos]

    # writing intact copies at end.
    img = create_image(pcs,pos)
    for i in range(PHASE1_FRAMES,PHASE1_FRAMES+PHASE2_FRAMES):
        write_frame(i,img)

    # writing gradually dissipating frames
    for i in range(PHASE1_FRAMES,0,-1):
        img = create_image(pcs,pos)
        write_frame(i, img)
        pos = move_pieces(pos, vecs)
        vecs = increase_vectors(vecs)
