
import re

text = open('deutschland_wm.txt').read()

text = text.lower()

baelle = re.findall('([a-z]*ball[a-z]*)', text)
print baelle

baelle = re.findall('(\w*ball\w*)', text, re.UNICODE)
print baelle

