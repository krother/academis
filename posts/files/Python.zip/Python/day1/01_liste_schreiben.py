
mannschaft = ['Schmelzer', 'Klose', 'Podolski', 'Sam', \
           'Neuer', 'Loew', 'Schweinsteiger', 'Paule']

nr = 1

for spieler in mannschaft:
    print nr, spieler
    nr = nr + 1



