
text = open('deutschland_wm.txt').read()

text = text.lower()

woerter = text.split()

print "Der Text enthaelt %5i Woerter."%(len(woerter))

count = {}
for w in woerter:
    count.setdefault(w, 0)
    count[w] = count[w] + 1

for w in count:
    if count[w] >= 5:
        print "%15s %8i" % (w, count[w])


