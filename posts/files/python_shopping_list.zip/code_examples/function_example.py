

def string_add(a, b):
    """concatenates two parameters as strings"""
    result =  str(a) + str(b)
    return result

print(string_add(1, 1))
print(string_add("hello", "world"))
c = string_add("3", 4)
print(c)
