
ausnahmen = ['Paule']

for zeile in open('spieler_dfb.txt'):
    name = zeile.strip()
    if name not in ausnahmen:
        print name


