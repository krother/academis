
import re

text = open('spiele.html').read()

anfang = text.find('Spiel 1')
text = text[anfang:]

spiele = text.split('class="mu result"')
for spiel in spiele:
    nationen = re.findall('\<span class\=\"t\-nText "\>(\w+)\<\/span\>', spiel)
    print nationen





