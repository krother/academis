#!/usr/bin/env python
#
# Example of a class derived from TestCase 
#

from unittest import TestCase
from word_counter import TextBody

MOBYDICK_SUMMARY = open('mobydick_summary.txt').read()

class AverageWordLengthTests(TestCase):
    """Tests for word_counter module."""

    def test_average_words(self):
        """Simple average length."""
        text = TextBody("white whale")
        #self.assertEqual(text.get_average_word_length(), ____)

    def test_average_words_complex(self):
        """Complex average length."""
        text = TextBody(MOBYDICK_SUMMARY)
        #self.assertAlmostEqual(text.get_average_word_length(), 4.630, ___)

    def test_average_empty(self):
        """Tests behaviour when input is not a string."""
        text = TextBody("")
        #self.assertRaises(____, text.get_average_word_length)
        

