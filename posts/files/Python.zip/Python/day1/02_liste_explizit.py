
print 1, 'Schmelzer'
print 2, 'Klose'
print 3, 'Podolski'
print 4, 'Sam'
print 5, 'Neuer'
print 6, 'Loew'
print 7, 'Schweinsteiger'
print 8, 'Paule'


