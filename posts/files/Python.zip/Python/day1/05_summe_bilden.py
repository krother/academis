
summe = 0.0

for zeile in open('tore.txt'):
    tore = int(zeile.strip())
    summe = summe + tore

print summe


