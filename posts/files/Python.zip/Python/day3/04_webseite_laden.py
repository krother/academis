
import urllib2

url = "http://de.fifa.com/worldcup/matches/"

page = urllib2.urlopen(url)
page = page.read()

open('page.html', 'w').write(page)

