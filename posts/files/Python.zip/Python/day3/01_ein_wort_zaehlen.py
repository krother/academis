
text = open('deutschland_wm.txt').read()

text = text.lower()

print text.count('ball')

